import fetch from 'node-fetch'

const API_HOST = 'https://aqueduct.fish.giraugh.xyz'
const API_PATH = '/long-running-timer-emails'
const API_FUNC_KEY = process.env.API_FUNC_KEY

export const handler = async (event, context, callback) => {
  
  // Perform API request to get emails of users w/ long-running timers
  const { emails } = await fetch(`${API_HOST}${API_PATH}?key=${API_FUNC_KEY}`)
    .then(r => r.json())
    .catch(error => {
      console.error(error)
      return { statusCode: 500, body: JSON.stringify({ error }) }
    })

  // Send emails

  // Return response of email addresses sent

  return {
    statusCode: 200,
    body: JSON.stringify(emails),
  }
}
